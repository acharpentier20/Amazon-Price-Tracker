//
//  ListViewController.swift
//  WebScraping
//
//  Created by McKensie Sherlock on 12/15/20.
//

import UIKit

class ListViewController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    
    // list of items
    var items = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.topItem?.title = "Items List"
        
        // Get all current saved items

    }
    
    @IBAction func didTapAdd() {
        // switch to another view controller to add entries
        let vc = storyboard?.instantiateViewController(identifier: "entry") as! ViewController
        vc.title = "New Item"
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
}

extension ListViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

extension ListViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = items[indexPath.row]
        
        return cell
    }
}
