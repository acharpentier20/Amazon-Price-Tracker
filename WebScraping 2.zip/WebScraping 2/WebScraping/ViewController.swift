//
//  ViewController.swift
//  WebScraping
//
//  Created by Alexis Charpentier on 11/12/20.
//

import UIKit
import SwiftSoup

class ViewController: UIViewController {
    @IBOutlet weak var linkSubmitButton: UIButton!
    @IBOutlet weak var productNameLabel: UILabel!
    @IBOutlet weak var priceNameLabel: UILabel!
    @IBOutlet weak var linkTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func textFieldDoneEditing(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        let myURLString = linkTextField.text!
        guard let myURL = URL(string: myURLString) else {
            print("Error: \(myURLString) not valid url")
            return
        }
        
        //initialize class constants
        let classNamePrice = "a-size-medium a-color-price priceBlockBuyingPriceString"
        let classNameProduct = "a-size-large product-title-word-break"
        
        do {
            // parse HTML from link
            let html = try String(contentsOf: myURL, encoding: .ascii)
            let doc: Document = try SwiftSoup.parse(html)
            
            // get and set product name
            let productName = try doc.getElementsByClass(classNameProduct)
            let productNameText = try productName.text()
            productNameLabel.text = productNameText
            
            // get and set product price
            let price: Element = try doc.getElementsByClass(classNamePrice).first()!
            let priceText = try price.text()
            priceNameLabel.text = priceText
            
            print("------")
            print(" Product: \(productNameText)")
            print(" Price: \(priceText)")
        } catch Exception.Error(type: let type, Message: let message){
            print(type)
            print(message)
        } catch {
            print("")
        }
    }
}

